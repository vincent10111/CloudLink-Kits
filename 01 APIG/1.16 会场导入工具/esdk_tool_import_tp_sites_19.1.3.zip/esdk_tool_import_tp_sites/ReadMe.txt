Tip:This tool can be run in Exchange2007��Exchange2010 and Exchange2013 server.

How to use this tool:
Double click the start.bat,according to the prompt enter the ip of the specified SMC service, the user name and password.