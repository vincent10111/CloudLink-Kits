var SERVERCONFIG = {
  MIDDLE_END_ADDRESS: "digitalworkplace.cn",
  LOGIN_ADDRESS: "bcloudec.huaweicloud.com",
  LOGIN_PORT: "8443"
};