module.exports = {
    "HISTORY": "历史"
}